export type PlanRequest = {
  eventName: string;
  eventType: string;
  date: string;
  location: string;
  guests: number;
  budgetInr: number;
  preferences: string[];
};

const API_BASE = "";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: { "Content-Type": "application/json", ...init?.headers },
  });
  if (!response.ok) throw new Error(`Request failed (${response.status})`);
  return response.json() as Promise<T>;
}

export const api = {
  health: () => request<{ status: string }>("/health"),
  generatePlan: (payload: PlanRequest) =>
    request<unknown>("/api/plan", { method: "POST", body: JSON.stringify(payload) }),
  chat: (eventId: number, message: string) =>
    request<unknown>("/api/chat", { method: "POST", body: JSON.stringify({ eventId, message }) }),
};
