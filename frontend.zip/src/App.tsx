import { FormEvent, ReactNode, useEffect, useMemo, useState } from "react";

type Page = "overview" | "events" | "planner" | "budget" | "tasks" | "vendors" | "inspiration" | "settings";
type EventItem = { id: number; name: string; type: string; date: string; location: string; guests: number; budget: number; progress: number; tone: string };
type Task = { id: number; title: string; event: string; due: string; done: boolean };
type Expense = { id: number; category: string; item: string; planned: number; actual: number };
type Vendor = { id: number; name: string; category: string; quote: number; status: "Considering" | "Booked"; phone: string };

const photos = [
  "https://images.unsplash.com/photo-1678514823362-fd5ec94505a2?auto=format&fit=crop&w=900&q=85",
  "https://images.unsplash.com/photo-1678514823267-437005e3ad50?auto=format&fit=crop&w=900&q=85",
  "https://images.unsplash.com/photo-1559563040-f2fc7416b7bb?auto=format&fit=crop&w=900&q=85",
  "https://images.unsplash.com/photo-1675437992142-a1865df78b83?auto=format&fit=crop&w=900&q=85",
];

const seedEvents: EventItem[] = [
  { id: 1, name: "Anaya's 21st", type: "Birthday", date: "2026-04-18", location: "The Courtyard, Jaipur", guests: 60, budget: 120000, progress: 72, tone: "peach" },
  { id: 2, name: "Riya & Kabir", type: "Engagement", date: "2026-05-09", location: "Lotus Gardens, Delhi", guests: 140, budget: 450000, progress: 48, tone: "pink" },
  { id: 3, name: "AURA '26", type: "College fest", date: "2026-06-12", location: "North Campus", guests: 850, budget: 800000, progress: 31, tone: "blue" },
];

const seedTasks: Task[] = [
  { id: 1, title: "Confirm cake tasting", event: "Anaya's 21st", due: "Today, 5:00 PM", done: false },
  { id: 2, title: "Review photographer quote", event: "Riya & Kabir", due: "Tomorrow", done: false },
  { id: 3, title: "Send volunteer brief", event: "AURA '26", due: "Fri, 11:00 AM", done: true },
  { id: 4, title: "Finalize floral palette", event: "Riya & Kabir", due: "18 Mar", done: false },
];

const seedExpenses: Expense[] = [
  { id: 1, category: "Venue", item: "Courtyard booking", planned: 50000, actual: 48000 },
  { id: 2, category: "Food", item: "Catering advance", planned: 35000, actual: 38000 },
  { id: 3, category: "Decoration", item: "Florals & lighting", planned: 18000, actual: 12500 },
  { id: 4, category: "Photography", item: "Photo + film", planned: 15000, actual: 15000 },
];

const seedVendors: Vendor[] = [
  { id: 1, name: "Demo Floral Studio", category: "Decoration", quote: 28500, status: "Booked", phone: "+91 98XX XXX 210" },
  { id: 2, name: "Sample Frame Co.", category: "Photography", quote: 42000, status: "Considering", phone: "+91 97XX XXX 614" },
  { id: 3, name: "Demo Table Kitchen", category: "Catering", quote: 96000, status: "Considering", phone: "+91 99XX XXX 032" },
];

const nav: { id: Page; label: string; icon: string }[] = [
  { id: "overview", label: "Overview", icon: "home" },
  { id: "events", label: "My events", icon: "calendar" },
  { id: "planner", label: "AI event planner", icon: "spark" },
  { id: "budget", label: "Budget tracker", icon: "wallet" },
  { id: "tasks", label: "Checklist & timeline", icon: "check" },
  { id: "vendors", label: "Vendors", icon: "users" },
  { id: "inspiration", label: "Inspiration", icon: "image" },
  { id: "settings", label: "Settings", icon: "settings" },
];

const iconPaths: Record<string, ReactNode> = {
  home: <><path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10M9 20v-6h6v6"/></>,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M16 3v4M8 3v4M3 10h18"/></>,
  spark: <><path d="m12 3 1.4 4.1L17.5 9l-4.1 1.4L12 15l-1.4-4.6L6.5 9l4.1-1.9L12 3Z"/><path d="m19 15 .7 2.3L22 18l-2.3.7L19 21l-.7-2.3L16 18l2.3-.7L19 15Z"/></>,
  wallet: <><path d="M4 6h14a2 2 0 0 1 2 2v11H4a2 2 0 0 1-2-2V6a3 3 0 0 1 3-3h12"/><path d="M16 12h6v4h-6a2 2 0 0 1 0-4Z"/></>,
  check: <><rect x="3" y="3" width="18" height="18" rx="4"/><path d="m7 12 3 3 7-7"/></>,
  users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/></>,
  image: <><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></>,
  settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6 1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"/></>,
  plus: <path d="M12 5v14M5 12h14"/>,
  arrow: <path d="M5 12h14m-5-5 5 5-5 5"/>,
  search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></>,
  trash: <><path d="M3 6h18M8 6V3h8v3M6 6l1 15h10l1-15M10 10v7M14 10v7"/></>,
  heart: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z"/>,
  menu: <path d="M4 7h16M4 12h16M4 17h16"/>,
};

function Icon({ name, size = 19, fill = "none" }: { name: string; size?: number; fill?: string }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{iconPaths[name]}</svg>;
}

function useStored<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try { return JSON.parse(localStorage.getItem(key) || "") || initial; } catch { return initial; }
  });
  useEffect(() => localStorage.setItem(key, JSON.stringify(value)), [key, value]);
  return [value, setValue] as const;
}

const money = (n: number) => `₹${n.toLocaleString("en-IN")}`;
const day = (date: string) => Math.max(0, Math.ceil((new Date(date).getTime() - Date.now()) / 86400000));

function Button({ children, onClick, kind = "dark", type = "button", disabled = false }: { children: ReactNode; onClick?: () => void; kind?: "dark" | "light" | "accent"; type?: "button" | "submit"; disabled?: boolean }) {
  return <button type={type} className={`btn ${kind}`} onClick={onClick} disabled={disabled}>{children}</button>;
}

function Progress({ value, color = "var(--ink)" }: { value: number; color?: string }) {
  return <div className="progress" role="progressbar" aria-valuenow={value} aria-valuemin={0} aria-valuemax={100}><span style={{ width: `${value}%`, background: color }}/></div>;
}

function PageTitle({ eyebrow, title, text, action }: { eyebrow: string; title: string; text: string; action?: ReactNode }) {
  return <header className="page-title"><div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{text}</p></div>{action}</header>;
}

function Overview({ events, tasks, setTasks, go }: { events: EventItem[]; tasks: Task[]; setTasks: (v: Task[]) => void; go: (p: Page) => void }) {
  const completed = tasks.filter(t => t.done).length;
  const planned = events.reduce((a, e) => a + e.budget, 0);
  return <>
    <PageTitle eyebrow="MONDAY, 16 MARCH" title={<>Good morning, <em>Meera.</em></>} text="Three celebrations are taking shape. Here's what needs your attention." action={<div className="title-actions"><Button kind="light" onClick={() => go("planner")}><Icon name="spark"/> Ask Planora</Button><Button onClick={() => go("planner")}><Icon name="plus"/> Plan an event</Button></div>}/>
    <section className="hero-grid">
      <article className="hero-card">
        <div className="hero-copy"><span className="pill dark">NEXT UP · 33 DAYS</span><h2>Anaya's big day,<br/><em>almost ready.</em></h2><p>A playful garden dinner with peach florals, warm lights, and her closest people.</p><Button kind="light" onClick={() => go("events")}>Open event <Icon name="arrow"/></Button></div>
        <div className="hero-art"><div className="sun"/><div className="flower f1"/><div className="flower f2"/><div className="flower f3"/><span>21</span></div>
      </article>
      <article className="ai-card"><div className="orb"><Icon name="spark" size={26}/></div><span className="eyebrow">PLANORA NOTE</span><h3>A little idea for Anaya</h3><p>A sunset mocktail bar fits the garden theme and can stay under ₹8,000.</p><button className="text-link" onClick={() => go("planner")}>Build this into the plan <Icon name="arrow" size={16}/></button></article>
    </section>
    <section className="metrics">
      <article><span>Total planned</span><strong>{money(planned)}</strong><small>Across 3 events</small></article>
      <article className="yellow"><span>Actual expenses</span><strong>{money(113500)}</strong><small>18% of planned</small></article>
      <article className="green"><span>Tasks completed</span><strong>{completed}<i> / {tasks.length}</i></strong><small>Keep the momentum</small></article>
      <article className="blue"><span>Avg. progress</span><strong>50%</strong><Progress value={50}/></article>
    </section>
    <div className="section-head"><div><span className="eyebrow">IN MOTION</span><h2>Upcoming events</h2></div><button className="text-link" onClick={() => go("events")}>View all <Icon name="arrow" size={16}/></button></div>
    <section className="event-row">{events.map((e, i) => <button className={`event-card ${e.tone}`} key={e.id} onClick={() => go("events")}><div className="date-tile"><b>{new Date(e.date).toLocaleDateString("en", { day: "2-digit" })}</b><span>{new Date(e.date).toLocaleDateString("en", { month: "short" })}</span></div><div><small>{e.type}</small><h3>{e.name}</h3><p>{e.location}</p></div><div className="event-progress"><b>{e.progress}%</b><Progress value={e.progress}/><span>{day(e.date)} days to go</span></div><span className="round-arrow">↗</span></button>)}</section>
    <section className="lower-grid">
      <article className="panel"><div className="section-head compact"><div><span className="eyebrow">THIS WEEK</span><h2>Next on your list</h2></div><button className="text-link" onClick={() => go("tasks")}>All tasks</button></div>
        <div className="task-list">{tasks.slice(0, 4).map(t => <label className={`task ${t.done ? "done" : ""}`} key={t.id}><input type="checkbox" checked={t.done} onChange={() => setTasks(tasks.map(x => x.id === t.id ? { ...x, done: !x.done } : x))}/><span className="custom-check"/><span><b>{t.title}</b><small>{t.event}</small></span><time>{t.due}</time></label>)}</div>
      </article>
      <article className="panel spending"><div className="section-head compact"><div><span className="eyebrow">MONEY MATTERS</span><h2>Budget pulse</h2></div><span className="pill">Healthy</span></div>
        <div className="donut" style={{"--p":"65%"} as React.CSSProperties}><div><strong>35%</strong><span>used</span></div></div>
        <div className="legend"><p><i className="dot ink"/>Committed <b>₹1.13L</b></p><p><i className="dot pale"/>Remaining <b>₹2.07L</b></p></div>
        <Button kind="light" onClick={() => go("budget")}>View budget</Button>
      </article>
    </section>
  </>;
}

function EventsPage({ events, setEvents }: { events: EventItem[]; setEvents: (e: EventItem[]) => void }) {
  const [show, setShow] = useState(false);
  const [selected, setSelected] = useState<EventItem | null>(null);
  const add = (ev: FormEvent<HTMLFormElement>) => {
    ev.preventDefault(); const f = new FormData(ev.currentTarget);
    setEvents([...events, { id: Date.now(), name: String(f.get("name")), type: String(f.get("type")), date: String(f.get("date")), location: String(f.get("location")), guests: Number(f.get("guests")), budget: Number(f.get("budget")), progress: 8, tone: "pink" }]);
    setShow(false);
  };
  return <>
    <PageTitle eyebrow="YOUR CELEBRATIONS" title={<>Plans worth <em>looking forward to.</em></>} text="Every detail, decision, and happy moment in one place." action={<Button onClick={() => setShow(true)}><Icon name="plus"/> New event</Button>}/>
    <section className="events-grid">{events.map((e, i) => <article className={`big-event ${e.tone}`} key={e.id}>
      <div className="event-number">0{i + 1}</div><span className="pill">{e.type}</span><h2>{e.name}</h2><p>{e.location}</p><div className="countdown"><strong>{day(e.date)}</strong><span>days<br/>to celebrate</span></div><Progress value={e.progress}/><div className="card-foot"><span>{e.progress}% planned</span><button onClick={() => setSelected(e)}>Open workspace <Icon name="arrow" size={16}/></button></div>
    </article>)}</section>
    {show && <Modal title="Create a new event" close={() => setShow(false)}><form onSubmit={add} className="form-grid"><Field label="Event name" name="name" required/><Field label="Event type" name="type" placeholder="Birthday, wedding..." required/><Field label="Date" name="date" type="date" required/><Field label="Location" name="location" required/><Field label="Guests" name="guests" type="number" required/><Field label="Budget (INR)" name="budget" type="number" required/><div className="form-actions"><Button kind="light" onClick={() => setShow(false)}>Cancel</Button><Button type="submit">Create event</Button></div></form></Modal>}
    {selected && <Modal title={selected.name} close={() => setSelected(null)}><div className="workspace"><span className="pill dark">{day(selected.date)} days to go</span><h2>{selected.progress}% of your plan is ready</h2><Progress value={selected.progress}/><div className="workspace-stats"><div><span>Budget</span><b>{money(selected.budget)}</b></div><div><span>Guests</span><b>{selected.guests}</b></div><div><span>Location</span><b>{selected.location}</b></div></div><div className="ai-inline"><Icon name="spark"/><div><b>Event-specific assistant</b><p>Ready for your backend connection. Demo suggestions are clearly labelled.</p></div></div></div></Modal>}
  </>;
}

function Field({ label, name, type = "text", placeholder, required = false, defaultValue }: { label: string; name: string; type?: string; placeholder?: string; required?: boolean; defaultValue?: string | number }) {
  return <label className="field"><span>{label}</span><input name={name} type={type} placeholder={placeholder} required={required} defaultValue={defaultValue}/></label>;
}

function Modal({ title, close, children }: { title: string; close: () => void; children: ReactNode }) {
  return <div className="modal-backdrop" role="presentation" onMouseDown={close}><section className="modal" role="dialog" aria-modal="true" aria-label={title} onMouseDown={e => e.stopPropagation()}><div className="modal-head"><h2>{title}</h2><button aria-label="Close dialog" onClick={close}>×</button></div>{children}</section></div>;
}

function Planner() {
  const [step, setStep] = useState(1); const [loading, setLoading] = useState(false); const [generated, setGenerated] = useState(false);
  const generate = () => { setLoading(true); setTimeout(() => { setLoading(false); setGenerated(true); setStep(3); }, 1200); };
  return <>
    <PageTitle eyebrow="SIGNATURE TOOL · DEMO MODE" title={<>Imagine it. <em>Plan it beautifully.</em></>} text="Tell Planora what you're celebrating and receive a thoughtful starting point in moments."/>
    <div className="wizard-shell">
      <aside className="steps">{["The occasion", "Your preferences", "Your plan"].map((s, i) => <div className={(step === i + 1 ? "active " : "") + (step > i + 1 ? "complete" : "")} key={s}><span>{step > i + 1 ? "✓" : `0${i + 1}`}</span><div><b>{s}</b><small>{i === 0 ? "Details & guests" : i === 1 ? "Budget & mood" : "A tailored roadmap"}</small></div></div>)}<div className="demo-note"><Icon name="spark"/><p><b>You're in demo mode.</b><br/>Results are curated examples—not live Gemini output.</p></div></aside>
      <section className="wizard">
        {step === 1 && <><span className="eyebrow">STEP ONE</span><h2>First, what's the occasion?</h2><p className="intro">The simple details that make every celebration unique.</p><div className="form-grid"><Field label="Event name" name="event" placeholder="e.g. Tara's garden birthday"/><label className="field"><span>Event type</span><select><option>Birthday</option><option>Wedding</option><option>Engagement</option><option>College event</option></select></label><Field label="Date" name="date" type="date"/><Field label="City or venue" name="location" placeholder="Jaipur, Rajasthan"/><Field label="Expected guests" name="guests" type="number" placeholder="80"/></div><div className="form-actions"><Button onClick={() => setStep(2)}>Continue <Icon name="arrow"/></Button></div></>}
        {step === 2 && <><span className="eyebrow">STEP TWO</span><h2>Shape the feeling.</h2><p className="intro">A few preferences help us build a plan that feels like yours.</p><div className="form-grid"><Field label="Budget in INR" name="budget" type="number" placeholder="150000"/><label className="field"><span>Budget flexibility</span><select><option>Keep it strict</option><option>Up to 10% flexible</option><option>Show me options</option></select></label><label className="field"><span>Celebration style</span><select><option>Warm & intimate</option><option>Bold & energetic</option><option>Classic & elegant</option><option>Playful & colourful</option></select></label><label className="field"><span>Setting</span><select><option>Outdoor</option><option>Indoor</option><option>Open to either</option></select></label><label className="field"><span>Dietary preferences</span><select><option>Vegetarian</option><option>Mixed menu</option><option>Vegan</option><option>Jain options</option></select></label><label className="field"><span>Main priority</span><select><option>Guest experience</option><option>Décor & atmosphere</option><option>Food</option><option>Staying on budget</option></select></label></div><div className="form-actions"><Button kind="light" onClick={() => setStep(1)}>Back</Button><Button onClick={generate} disabled={loading}>{loading ? <><span className="spinner"/> Crafting your plan...</> : <><Icon name="spark"/> Generate demo plan</>}</Button></div></>}
        {step === 3 && generated && <PlanResult regenerate={generate}/>}
      </section>
    </div>
  </>;
}

function PlanResult({ regenerate }: { regenerate: () => void }) {
  return <><div className="result-head"><div><span className="pill success">DEMO PLAN READY</span><h2>Sunset in Bloom</h2><p>A relaxed garden celebration where soft peach florals meet candlelight and joyful colour.</p></div><div className="palette"><i/><i/><i/><i/></div></div>
    <div className="result-grid">
      <article className="result-card wide"><span className="eyebrow">CONCEPT</span><h3>A garden that glows after sunset</h3><p>Long shared tables, seasonal marigolds, playful paper details, and a central mocktail bar. Keep the ceremony area airy and let warm lighting transform it after dusk.</p></article>
      <article className="result-card"><span className="eyebrow">BUDGET SPLIT</span>{[["Food & drinks","38%"],["Venue","24%"],["Décor","18%"],["Photo","12%"],["Buffer","8%"]].map(x => <p className="split" key={x[0]}><span>{x[0]}</span><b>{x[1]}</b></p>)}</article>
      <article className="result-card"><span className="eyebrow">MENU NOTES</span><h3>Bright, local, easy</h3><p>Chaat bar · Seasonal coolers<br/>Family-style mains · Mini mithai<br/>One statement birthday cake</p></article>
      <article className="result-card wide timeline"><span className="eyebrow">PREPARATION TIMELINE</span>{[["8 weeks","Book venue & key vendors"],["4 weeks","Confirm menu and design"],["1 week","Final calls and guest count"],["Event day","Set up, check, celebrate"]].map(x => <div key={x[0]}><b>{x[0]}</b><span>{x[1]}</span></div>)}</article>
      <article className="result-card saving"><Icon name="spark"/><div><span className="eyebrow">COST-SAVING IDEA</span><p>Reuse ceremony florals at the cake and welcome areas to save an estimated ₹6,000–₹10,000.</p></div></article>
    </div><div className="form-actions"><Button kind="light" onClick={regenerate}>Regenerate</Button><Button>Save plan</Button><Button kind="accent">Export</Button></div>
  </>;
}

function Budget({ expenses, setExpenses }: { expenses: Expense[]; setExpenses: (e: Expense[]) => void }) {
  const [show, setShow] = useState(false); const planned = expenses.reduce((a, e) => a + e.planned, 0); const actual = expenses.reduce((a, e) => a + e.actual, 0);
  const add = (ev: FormEvent<HTMLFormElement>) => { ev.preventDefault(); const f = new FormData(ev.currentTarget); setExpenses([...expenses, { id: Date.now(), category: String(f.get("category")), item: String(f.get("item")), planned: Number(f.get("planned")), actual: Number(f.get("actual")) }]); setShow(false); };
  return <><PageTitle eyebrow="CLEAR NUMBERS, CALMER PLANNING" title={<>Your budget, <em>at a glance.</em></>} text="Deterministic totals update the moment you add or remove an expense." action={<Button onClick={() => setShow(true)}><Icon name="plus"/> Add expense</Button>}/>
    <section className="metrics budget-metrics"><article><span>Planned</span><strong>{money(planned)}</strong><small>Current categories</small></article><article className={actual > planned ? "warning" : "yellow"}><span>Actual</span><strong>{money(actual)}</strong><small>{actual > planned ? "Over planned amount" : `${Math.round(actual / planned * 100)}% utilized`}</small></article><article className="green"><span>Remaining</span><strong>{money(planned - actual)}</strong><small>Updates instantly</small></article></section>
    {actual > planned && <div className="alert" role="alert">Your actual expenses are above the planned total. Review high-spend categories before confirming new vendors.</div>}
    <section className="panel"><div className="section-head compact"><div><span className="eyebrow">CATEGORY VIEW</span><h2>Planned vs. actual</h2></div></div><div className="expense-table"><div className="tr table-head"><span>Expense</span><span>Category</span><span>Planned</span><span>Actual</span><span/></div>{expenses.map(e => <div className="tr" key={e.id}><b>{e.item}</b><span><i className="dot ink"/>{e.category}</span><span>{money(e.planned)}</span><strong className={e.actual > e.planned ? "over" : ""}>{money(e.actual)}</strong><button aria-label={`Delete ${e.item}`} onClick={() => setExpenses(expenses.filter(x => x.id !== e.id))}><Icon name="trash" size={17}/></button></div>)}</div></section>
    {show && <Modal title="Add an expense" close={() => setShow(false)}><form className="form-grid" onSubmit={add}><Field label="Item" name="item" required/><Field label="Category" name="category" required/><Field label="Planned amount" name="planned" type="number" required/><Field label="Actual amount" name="actual" type="number" required/><div className="form-actions"><Button type="submit">Add expense</Button></div></form></Modal>}
  </>;
}

function TasksPage({ tasks, setTasks }: { tasks: Task[]; setTasks: (t: Task[]) => void }) {
  const [filter, setFilter] = useState("All"); const [text, setText] = useState("");
  const visible = tasks.filter(t => filter === "All" || (filter === "Done" ? t.done : !t.done));
  const add = () => { if (text.trim()) { setTasks([...tasks, { id: Date.now(), title: text, event: "General planning", due: "No date", done: false }]); setText(""); } };
  return <><PageTitle eyebrow="ONE STEP AT A TIME" title={<>A calmer way to <em>get it done.</em></>} text={`${tasks.filter(t => t.done).length} of ${tasks.length} tasks complete across your celebrations.`}/>
    <section className="panel task-page"><div className="task-tools"><div className="add-task"><input value={text} onChange={e => setText(e.target.value)} placeholder="Add a task..." onKeyDown={e => e.key === "Enter" && add()}/><Button onClick={add}><Icon name="plus"/> Add</Button></div><div className="filter-pills">{["All","Open","Done"].map(x => <button key={x} className={filter === x ? "active" : ""} onClick={() => setFilter(x)}>{x}</button>)}</div></div>
      <div className="timeline-list">{visible.map((t, i) => <div className={`timeline-task ${t.done ? "done" : ""}`} key={t.id}><div className="timeline-mark"><span>{t.done ? "✓" : i + 1}</span></div><label><input type="checkbox" checked={t.done} onChange={() => setTasks(tasks.map(x => x.id === t.id ? {...x, done: !x.done} : x))}/><div><b>{t.title}</b><small>{t.event} · {t.due}</small></div></label><button onClick={() => setTasks(tasks.filter(x => x.id !== t.id))}><Icon name="trash" size={17}/></button></div>)}</div>
    </section>
  </>;
}

function Vendors({ vendors, setVendors }: { vendors: Vendor[]; setVendors: (v: Vendor[]) => void }) {
  const [search, setSearch] = useState(""); const [show, setShow] = useState(false);
  const filtered = vendors.filter(v => `${v.name} ${v.category}`.toLowerCase().includes(search.toLowerCase()));
  const add = (ev: FormEvent<HTMLFormElement>) => { ev.preventDefault(); const f = new FormData(ev.currentTarget); setVendors([...vendors, { id: Date.now(), name: String(f.get("name")), category: String(f.get("category")), quote: Number(f.get("quote")), phone: String(f.get("phone")), status: "Considering" }]); setShow(false); };
  return <><PageTitle eyebrow="YOUR CREATIVE CREW" title={<>Good people make <em>great events.</em></>} text="Demo records only. No listed provider is real or verified." action={<Button onClick={() => setShow(true)}><Icon name="plus"/> Add vendor</Button>}/>
    <div className="searchbar"><Icon name="search"/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by vendor or category"/></div>
    <section className="vendor-grid">{filtered.map((v, i) => <article className="vendor-card" key={v.id}><div className={`vendor-logo c${i % 4}`}>{v.name.split(" ").slice(0,2).map(x => x[0]).join("")}</div><span className={`status ${v.status === "Booked" ? "booked" : ""}`}>{v.status}</span><h3>{v.name}</h3><p>{v.category}</p><div className="vendor-details"><span>Quote <b>{money(v.quote)}</b></span><span>Contact <b>{v.phone}</b></span></div><div className="vendor-actions"><button onClick={() => setVendors(vendors.map(x => x.id === v.id ? {...x, status: x.status === "Booked" ? "Considering" : "Booked"} : x))}>{v.status === "Booked" ? "Mark considering" : "Mark booked"}</button><button aria-label={`Delete ${v.name}`} onClick={() => setVendors(vendors.filter(x => x.id !== v.id))}><Icon name="trash" size={17}/></button></div></article>)}</section>
    {show && <Modal title="Add a vendor" close={() => setShow(false)}><form className="form-grid" onSubmit={add}><Field label="Display name" name="name" required/><Field label="Category" name="category" required/><Field label="Quote (INR)" name="quote" type="number" required/><Field label="Contact number" name="phone" required/><div className="form-actions"><Button type="submit">Save vendor</Button></div></form></Modal>}
  </>;
}

const ideas = [
  { id: 1, title: "Marigold twilight", cat: "Wedding", desc: "Layered fabric, local flowers, and warm pendant lights.", colors: ["#ED8B75","#F4CD68","#61744B"], range: "₹1.2L–₹2.4L" },
  { id: 2, title: "Pastel garden table", cat: "Birthday", desc: "Soft linen, playful menus, and shared-table dining.", colors: ["#F2B5C9","#C4CDED","#F5E6C8"], range: "₹45K–₹90K" },
  { id: 3, title: "Courtyard sangeet", cat: "Engagement", desc: "A colour-rich canopy with an intimate dance floor.", colors: ["#A85584","#F5A1C5","#D9C76C"], range: "₹1.8L–₹3.5L" },
  { id: 4, title: "Campus after dark", cat: "College", desc: "String lights, open seating, and bold wayfinding.", colors: ["#252340","#7A88CC","#EC8E82"], range: "₹2L–₹5L" },
];

function Inspiration({ go }: { go: (p: Page) => void }) {
  const [faves, setFaves] = useStored<number[]>("planora-faves", []); const [category, setCategory] = useState("All");
  const visible = ideas.filter(i => category === "All" || i.cat === category);
  return <><PageTitle eyebrow="IDEAS TO MAKE YOUR OWN" title={<>Find your <em>celebration feeling.</em></>} text="A curated starting point for colours, atmosphere, and thoughtful details."/>
    <div className="filter-pills gallery-filter">{["All","Wedding","Birthday","Engagement","College"].map(x => <button className={category === x ? "active" : ""} onClick={() => setCategory(x)} key={x}>{x}</button>)}</div>
    <section className="gallery">{visible.map((idea, i) => <article className="idea" key={idea.id}><div className="idea-image"><img src={photos[i % photos.length]} alt={`${idea.title} celebration inspiration`}/><button className={faves.includes(idea.id) ? "liked" : ""} aria-label="Favorite idea" onClick={() => setFaves(faves.includes(idea.id) ? faves.filter(x => x !== idea.id) : [...faves, idea.id])}><Icon name="heart" fill={faves.includes(idea.id) ? "currentColor" : "none"}/></button><span>{idea.cat}</span></div><div className="idea-body"><h3>{idea.title}</h3><p>{idea.desc}</p><div className="idea-meta"><div className="swatches">{idea.colors.map(c => <i key={c} style={{background:c}}/>)}</div><b>{idea.range}</b></div><Button kind="light" onClick={() => go("planner")}>Use this idea <Icon name="arrow" size={16}/></Button></div></article>)}</section>
    <p className="photo-credit">Photography sourced from Unsplash. Images are for inspiration only.</p>
  </>;
}

function Settings({ clear }: { clear: () => void }) {
  const [confirm, setConfirm] = useState(false); const [saved, setSaved] = useState(false);
  const exportData = () => { const blob = new Blob([JSON.stringify({ events: JSON.parse(localStorage.getItem("planora-events") || "[]"), tasks: JSON.parse(localStorage.getItem("planora-tasks") || "[]") }, null, 2)], {type:"application/json"}); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "planora-data.json"; a.click(); URL.revokeObjectURL(a.href); };
  return <><PageTitle eyebrow="MAKE IT YOURS" title={<>Preferences, <em>your way.</em></>} text="Profile, planning defaults, notifications, and your local demonstration data."/>
    <section className="settings-grid"><article className="panel"><span className="eyebrow">PROFILE & DEFAULTS</span><h2>Planning preferences</h2><div className="form-grid settings-form"><Field label="Display name" name="name" defaultValue="Meera Sharma"/><Field label="Default guest count" name="guests" type="number" defaultValue={80}/><label className="field"><span>Currency</span><select defaultValue="INR"><option value="INR">INR — Indian Rupee</option></select></label><label className="field"><span>Celebration style</span><select><option>Warm & intimate</option><option>Bold & energetic</option><option>Classic & elegant</option></select></label></div><Button onClick={() => {setSaved(true); setTimeout(() => setSaved(false), 1800)}}>{saved ? "Preferences saved" : "Save changes"}</Button></article>
    <article className="panel"><span className="eyebrow">NOTIFICATIONS</span><h2>Gentle reminders</h2>{["Upcoming task reminders","Budget threshold alerts","Weekly planning digest"].map((x,i) => <label className="toggle-row" key={x}><span><b>{x}</b><small>{i === 0 ? "One day before a task is due" : i === 1 ? "When a category reaches 90%" : "A short Sunday overview"}</small></span><input type="checkbox" defaultChecked={i < 2}/><i/></label>)}</article>
    <article className="panel data-panel"><span className="eyebrow">YOUR DATA</span><h2>Export or reset</h2><p>Everything in this demo stays in this browser. Export a JSON copy or clear it to return to the sample experience.</p><div className="form-actions"><Button kind="light" onClick={exportData}>Export JSON</Button><button className="danger-link" onClick={() => setConfirm(true)}>Clear demonstration data</button></div></article></section>
    {confirm && <Modal title="Clear demonstration data?" close={() => setConfirm(false)}><p>This removes your locally saved events, tasks, expenses, vendors, and favorites. This cannot be undone.</p><div className="form-actions"><Button kind="light" onClick={() => setConfirm(false)}>Keep my data</Button><button className="danger-btn" onClick={() => {clear(); setConfirm(false)}}>Yes, clear data</button></div></Modal>}
  </>;
}

export default function App() {
  const [page, setPage] = useState<Page>("overview"); const [mobileOpen, setMobileOpen] = useState(false);
  const [events, setEvents] = useStored("planora-events", seedEvents); const [tasks, setTasks] = useStored("planora-tasks", seedTasks);
  const [expenses, setExpenses] = useStored("planora-expenses", seedExpenses); const [vendors, setVendors] = useStored("planora-vendors", seedVendors);
  const go = (p: Page) => { setPage(p); setMobileOpen(false); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const clear = () => { localStorage.clear(); setEvents(seedEvents); setTasks(seedTasks); setExpenses(seedExpenses); setVendors(seedVendors); };
  const content = useMemo(() => {
    if (page === "overview") return <Overview events={events} tasks={tasks} setTasks={setTasks} go={go}/>;
    if (page === "events") return <EventsPage events={events} setEvents={setEvents}/>;
    if (page === "planner") return <Planner/>;
    if (page === "budget") return <Budget expenses={expenses} setExpenses={setExpenses}/>;
    if (page === "tasks") return <TasksPage tasks={tasks} setTasks={setTasks}/>;
    if (page === "vendors") return <Vendors vendors={vendors} setVendors={setVendors}/>;
    if (page === "inspiration") return <Inspiration go={go}/>;
    return <Settings clear={clear}/>;
  }, [page, events, tasks, expenses, vendors]);
  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? "open" : ""}`}><div className="brand" onClick={() => go("overview")}><span className="brand-mark"><i/><i/><i/></span><b>planora</b><small>AI</small></div><nav aria-label="Main navigation">{nav.map(n => <button key={n.id} className={page === n.id ? "active" : ""} onClick={() => go(n.id)}><Icon name={n.icon}/><span>{n.label}</span>{n.id === "tasks" && <i className="count">{tasks.filter(t => !t.done).length}</i>}</button>)}</nav><div className="sidebar-foot"><div className="mini-avatar">MS</div><div><b>Meera Sharma</b><span>Demo workspace</span></div><button onClick={() => go("settings")} aria-label="Open settings"><Icon name="settings" size={17}/></button></div></aside>
    {mobileOpen && <button className="nav-backdrop" aria-label="Close navigation" onClick={() => setMobileOpen(false)}/>}
    <main><div className="mobile-head"><button aria-label="Open navigation" onClick={() => setMobileOpen(true)}><Icon name="menu"/></button><div className="brand"><span className="brand-mark"><i/><i/><i/></span><b>planora</b></div><button aria-label="Notifications"><Icon name="bell"/></button></div><div className="topbar"><div className="demo-badge"><i/> DEMO MODE</div><button className="icon-btn" aria-label="Search"><Icon name="search"/></button><button className="icon-btn notification" aria-label="Notifications"><Icon name="bell"/><i/></button></div><div className="page-content">{content}</div></main>
  </div>;
}
