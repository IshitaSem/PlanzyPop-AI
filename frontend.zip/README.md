# Planora AI

A responsive celebration-planning frontend for Hack2Skill Challenge 5. The app includes events, a demo AI planning wizard, deterministic budget calculations, checklists, vendor organization, inspiration favorites, settings, JSON export, and browser-local persistence.

## Run locally

```bash
pnpm install
pnpm dev
```

The Figma Make workspace already starts the development server. Use `pnpm build` for a production build.

## AI and API status

The current planner is clearly labelled **Demo mode** and returns a curated sample plan. No API key is used or stored in the browser. `src/services/api.ts` provides typed integration points for:

- `GET /health`
- `POST /api/plan`
- `POST /api/chat`

Connect these routes to the Python backend for real Gemini responses. Keep the Gemini API key on the server only.

## Data

Demo data is saved to `localStorage`. Settings includes JSON export and a confirmed reset action. Financial totals are calculated locally and never delegated to AI.

## Images

Inspiration photography is served from Unsplash and credited in the interface.
